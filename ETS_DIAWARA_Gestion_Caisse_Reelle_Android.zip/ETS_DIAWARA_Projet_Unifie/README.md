# ETS DIAWARA Gestion — projet unifié (prototype avec caisse réelle)

## Fonctionnalités
- Base SQLite locale et fonctionnement hors ligne après installation.
- Catalogue produits, achats et ventes reliés au stock.
- Caisse en MRU : le solde initial est saisi une seule fois.
- Les ventes ajoutent uniquement le montant réellement encaissé à la caisse.
- Les achats retirent uniquement le montant réellement payé.
- Entrées et sorties manuelles réelles avec catégorie, motif, montant et date.
- Comptage physique : enregistre le montant compté, le solde théorique au moment du comptage et l'écart. Le comptage ne modifie pas silencieusement les mouvements.
- Migration SQLite prévue de la version 1 vers la version 2 pour ajouter les tables de caisse.
- Configuration GitHub Actions fournie à titre de modèle dans `.github/workflows/build-apk.yml`.

## Important
Ce projet est encore un prototype source : il n'a pas été compilé ni testé sur un appareil Android dans cet environnement. Ne l'utilise pas comme seul registre de caisse avant d'avoir testé les calculs et fait une sauvegarde. Les produits et prix créés automatiquement sont des exemples à remplacer.

## Compiler depuis un téléphone Android avec GitHub Actions
Le dossier source doit être disponible dans un dépôt GitHub et un workflow doit être ajouté dans `.github/workflows/build-apk.yml`. Le workflow de ce ZIP est un modèle, mais un fichier workflow placé uniquement dans le ZIP n'est pas activé automatiquement par GitHub : le fichier YAML doit être créé dans le dépôt GitHub lui-même.

Le workflow fourni recherche à la racine du dépôt `ETS_DIAWARA_Gestion_Caisse_Reelle_Android.zip` (ou, en secours, `ETS_DIAWARA_Projet_Unifie.zip`), décompresse le projet, génère les fichiers de plateforme Android, exécute `flutter analyze`, puis construit l'APK release. L'APK apparaît comme artefact dans l'exécution GitHub Actions si toutes les étapes réussissent.

## Limites actuelles
- Achats et ventes : un produit par opération, pas encore de panier multi-produits.
- Factures PDF, rapports avancés, fiches clients/fournisseurs dédiées, export Excel et sauvegarde/restauration restent à développer.
- Les paiements ultérieurs de dettes ne sont pas encore gérés par un écran dédié : ne pas les saisir comme une nouvelle vente.
- Les produits de démonstration et leurs prix ne sont pas les données réelles du commerce.
