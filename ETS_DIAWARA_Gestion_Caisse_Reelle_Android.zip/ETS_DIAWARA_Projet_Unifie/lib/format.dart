String formatMRU(num value) {
  final s = value.round().toString();
  final out = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    out.write(s[i]);
    if (i < s.length - 1 && (s.length - i - 1) % 3 == 0) out.write(' ');
  }
  return '${out.toString()} MRU';
}
