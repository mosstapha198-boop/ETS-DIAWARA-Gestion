import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class EtsDatabase {
  EtsDatabase._();
  static final EtsDatabase instance = EtsDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = p.join(await getDatabasesPath(), 'ets_diawara_unified.db');
    _db = await openDatabase(dbPath, version: 2,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          brand TEXT NOT NULL, model TEXT NOT NULL, capacity TEXT NOT NULL DEFAULT '',
          condition TEXT NOT NULL DEFAULT 'Neuf',
          quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
          alert_threshold INTEGER NOT NULL DEFAULT 2 CHECK(alert_threshold >= 0),
          purchase_price_mru INTEGER NOT NULL DEFAULT 0 CHECK(purchase_price_mru >= 0),
          sale_price_mru INTEGER NOT NULL DEFAULT 0 CHECK(sale_price_mru >= 0),
          sku TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )''');
        await db.execute('''CREATE TABLE purchases(
          id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_number TEXT NOT NULL UNIQUE,
          supplier TEXT NOT NULL, reference TEXT NOT NULL, product_id INTEGER,
          product_label TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity > 0),
          unit_cost_mru INTEGER NOT NULL CHECK(unit_cost_mru >= 0),
          transport_mru INTEGER NOT NULL DEFAULT 0 CHECK(transport_mru >= 0),
          other_mru INTEGER NOT NULL DEFAULT 0 CHECK(other_mru >= 0),
          goods_total_mru INTEGER NOT NULL, total_mru INTEGER NOT NULL,
          paid_mru INTEGER NOT NULL CHECK(paid_mru >= 0), balance_mru INTEGER NOT NULL CHECK(balance_mru >= 0),
          created_at TEXT NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
        )''');
        await db.execute('''CREATE TABLE sales(
          id INTEGER PRIMARY KEY AUTOINCREMENT, sale_number TEXT NOT NULL UNIQUE,
          product_id INTEGER, product_label TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity > 0),
          unit_price_mru INTEGER NOT NULL CHECK(unit_price_mru >= 0),
          total_mru INTEGER NOT NULL, paid_mru INTEGER NOT NULL CHECK(paid_mru >= 0),
          balance_mru INTEGER NOT NULL CHECK(balance_mru >= 0), created_at TEXT NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
        )''');
        await db.execute('''CREATE TABLE cash_movements(
          id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL CHECK(kind IN ('IN','OUT')),
          category TEXT NOT NULL, label TEXT NOT NULL, amount_mru INTEGER NOT NULL CHECK(amount_mru > 0),
          reference_type TEXT NOT NULL DEFAULT '', reference_id INTEGER,
          created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE stock_movements(
          id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, movement_type TEXT NOT NULL,
          quantity INTEGER NOT NULL CHECK(quantity > 0), unit_cost_mru INTEGER NOT NULL DEFAULT 0,
          reference_type TEXT NOT NULL DEFAULT '', reference_id INTEGER, note TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
        )''');
        await db.execute('CREATE INDEX idx_purchases_date ON purchases(created_at)');
        await db.execute('CREATE INDEX idx_sales_date ON sales(created_at)');
        await db.execute('CREATE INDEX idx_cash_date ON cash_movements(created_at)');
        await db.execute('''CREATE TABLE cash_settings(
          id INTEGER PRIMARY KEY CHECK(id = 1), opening_balance_mru INTEGER NOT NULL DEFAULT 0 CHECK(opening_balance_mru >= 0),
          is_opening_set INTEGER NOT NULL DEFAULT 0 CHECK(is_opening_set IN (0,1)), opening_set_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE cash_counts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, expected_balance_mru INTEGER NOT NULL, counted_balance_mru INTEGER NOT NULL CHECK(counted_balance_mru >= 0),
          difference_mru INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        )''');
        await db.insert('cash_settings', {'id':1, 'opening_balance_mru':0, 'is_opening_set':0, 'opening_set_at':DateTime.now().toIso8601String()});
        await db.insert('products', {'brand':'Samsung','model':'A16','capacity':'128 Go','condition':'Neuf','quantity':10,'alert_threshold':2,'purchase_price_mru':3400,'sale_price_mru':3990});
        await db.insert('products', {'brand':'Samsung','model':'A26','capacity':'128 Go','condition':'Neuf','quantity':5,'alert_threshold':2,'purchase_price_mru':5500,'sale_price_mru':6260});
        await db.insert('products', {'brand':'Accessoire','model':'Chargeur USB-C','capacity':'','condition':'Neuf','quantity':25,'alert_threshold':5,'purchase_price_mru':200,'sale_price_mru':350});
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('''CREATE TABLE cash_settings(
            id INTEGER PRIMARY KEY CHECK(id = 1), opening_balance_mru INTEGER NOT NULL DEFAULT 0 CHECK(opening_balance_mru >= 0),
            is_opening_set INTEGER NOT NULL DEFAULT 0 CHECK(is_opening_set IN (0,1)), opening_set_at TEXT NOT NULL
          )''');
          await db.execute('''CREATE TABLE cash_counts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, expected_balance_mru INTEGER NOT NULL, counted_balance_mru INTEGER NOT NULL CHECK(counted_balance_mru >= 0),
            difference_mru INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
          )''');
          await db.insert('cash_settings', {'id':1, 'opening_balance_mru':0, 'is_opening_set':0, 'opening_set_at':DateTime.now().toIso8601String()});
        }
      });
    return _db!;
  }

  String _now() => DateTime.now().toIso8601String();
  Future<List<Map<String,Object?>>> products() async => (await database).query('products', orderBy:'brand COLLATE NOCASE, model COLLATE NOCASE');

  Future<void> addProduct({required String brand, required String model, required String capacity,
    required String condition, required int purchasePrice, required int salePrice, required int stock}) async {
    if (brand.trim().isEmpty || model.trim().isEmpty || purchasePrice < 0 || salePrice < 0 || stock < 0) {
      throw Exception('Vérifie la marque, le modèle, les prix et le stock.');
    }
    await (await database).insert('products', {
      'brand':brand.trim(), 'model':model.trim(), 'capacity':capacity.trim(), 'condition':condition,
      'purchase_price_mru':purchasePrice, 'sale_price_mru':salePrice, 'quantity':stock, 'alert_threshold':2,
    });
  }

  Future<String> createPurchase({required int productId, required String supplier, required String reference,
    required int quantity, required int unitCost, required int transport, required int other, required int paid}) async {
    if (supplier.trim().isEmpty) throw Exception('Saisis le nom du fournisseur.');
    if (reference.trim().isEmpty) throw Exception('Saisis une référence d’achat.');
    if (quantity <= 0 || unitCost < 0 || transport < 0 || other < 0) throw Exception('Vérifie la quantité et les frais.');
    final db = await database;
    return db.transaction((txn) async {
      final rows = await txn.query('products', where:'id = ?', whereArgs:[productId], limit:1);
      if (rows.isEmpty) throw Exception('Produit introuvable.');
      final product = rows.first;
      final goods = quantity * unitCost;
      final total = goods + transport + other;
      if (paid < 0 || paid > total) throw Exception('Le montant payé doit être entre 0 et le total de l’achat.');
      final n = Sqflite.firstIntValue(await txn.rawQuery('SELECT COUNT(*) FROM purchases')) ?? 0;
      final number = 'ACH-${DateTime.now().year}-${(n+1).toString().padLeft(5,'0')}';
      final now = _now();
      final id = await txn.insert('purchases', {
        'purchase_number':number, 'supplier':supplier.trim(), 'reference':reference.trim(),
        'product_id':productId, 'product_label':'${product['brand']} ${product['model']} ${product['capacity']}',
        'quantity':quantity, 'unit_cost_mru':unitCost, 'transport_mru':transport, 'other_mru':other,
        'goods_total_mru':goods, 'total_mru':total, 'paid_mru':paid, 'balance_mru':total-paid, 'created_at':now,
      });
      await txn.rawUpdate('UPDATE products SET quantity = quantity + ?, purchase_price_mru = ? WHERE id = ?', [quantity, unitCost, productId]);
      await txn.insert('stock_movements', {'product_id':productId,'movement_type':'PURCHASE_IN','quantity':quantity,
        'unit_cost_mru':unitCost,'reference_type':'PURCHASE','reference_id':id,'note':'Entrée ${number}','created_at':now});
      if (paid > 0) {
        await txn.insert('cash_movements', {'kind':'OUT','category':'ACHAT','label':'Paiement fournisseur ${number}',
          'amount_mru':paid,'reference_type':'PURCHASE','reference_id':id,'created_at':now});
      }
      return number;
    });
  }

  Future<String> createSale({required int productId, required int quantity, required int paid}) async {
    if (quantity <= 0) throw Exception('La quantité doit être supérieure à zéro.');
    final db = await database;
    return db.transaction((txn) async {
      final rows = await txn.query('products', where:'id = ?', whereArgs:[productId], limit:1);
      if (rows.isEmpty) throw Exception('Produit introuvable.');
      final product = rows.first;
      final stock = product['quantity'] as int;
      if (stock < quantity) throw Exception('Stock insuffisant : $stock unité(s) disponible(s).');
      final unitPrice = product['sale_price_mru'] as int;
      final total = unitPrice * quantity;
      if (paid < 0 || paid > total) throw Exception('Le montant encaissé doit être entre 0 et le total de la vente.');
      final n = Sqflite.firstIntValue(await txn.rawQuery('SELECT COUNT(*) FROM sales')) ?? 0;
      final number = 'V-${DateTime.now().year}-${(n+1).toString().padLeft(5,'0')}';
      final now = _now();
      final id = await txn.insert('sales', {'sale_number':number,'product_id':productId,
        'product_label':'${product['brand']} ${product['model']} ${product['capacity']}',
        'quantity':quantity,'unit_price_mru':unitPrice,'total_mru':total,'paid_mru':paid,
        'balance_mru':total-paid,'created_at':now});
      await txn.rawUpdate('UPDATE products SET quantity = quantity - ? WHERE id = ?', [quantity, productId]);
      await txn.insert('stock_movements', {'product_id':productId,'movement_type':'SALE_OUT','quantity':quantity,
        'reference_type':'SALE','reference_id':id,'note':'Sortie ${number}','created_at':now});
      if (paid > 0) await txn.insert('cash_movements', {'kind':'IN','category':'VENTE','label':'Encaissement ${number}',
        'amount_mru':paid,'reference_type':'SALE','reference_id':id,'created_at':now});
      return number;
    });
  }

  Future<List<Map<String,Object?>>> purchaseHistory() async => (await database).query('purchases', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> salesHistory() async => (await database).query('sales', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> cashMovements() async => (await database).query('cash_movements', orderBy:'id DESC');

  Future<int> cashOpeningBalance() async {
    final db = await database;
    final rows = await db.query('cash_settings', where: 'id = 1', limit: 1);
    return rows.isEmpty ? 0 : (rows.first['opening_balance_mru'] as num).toInt();
  }

  Future<bool> hasOpeningBalance() async {
    final db = await database;
    final rows = await db.query('cash_settings', where: 'id = 1', limit: 1);
    return rows.isNotEmpty && (rows.first['is_opening_set'] as int) == 1;
  }

  Future<void> setOpeningBalance(int amount) async {
    if (amount < 0) throw Exception('Le solde initial ne peut pas être négatif.');
    final db = await database;
    final rows = await db.query('cash_settings', where: 'id = 1', limit: 1);
    if (rows.isNotEmpty && (rows.first['is_opening_set'] as int) == 1) throw Exception('Le solde initial est déjà défini. Pour corriger la caisse, enregistre une entrée ou une sortie de régularisation.');
    await db.insert('cash_settings', {'id':1, 'opening_balance_mru':amount, 'is_opening_set':1, 'opening_set_at':_now()}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> addCashMovement({required String kind, required String category, required String label, required int amount}) async {
    if (kind != 'IN' && kind != 'OUT') throw Exception('Type de mouvement invalide.');
    if (category.trim().isEmpty || label.trim().isEmpty || amount <= 0) throw Exception('Saisis une catégorie, un motif et un montant supérieur à zéro.');
    final db = await database;
    await db.insert('cash_movements', {'kind':kind, 'category':category.trim(), 'label':label.trim(),
      'amount_mru':amount, 'reference_type':'MANUAL', 'reference_id':null, 'created_at':_now()});
  }

  Future<int> cashBalance() async {
    final db = await database;
    final opening = await cashOpeningBalance();
    final rows = await db.rawQuery("SELECT COALESCE(SUM(CASE WHEN kind='IN' THEN amount_mru ELSE -amount_mru END),0) balance FROM cash_movements");
    return opening + (rows.first['balance'] as num).toInt();
  }

  Future<void> recordCashCount({required int counted, String note = ''}) async {
    if (counted < 0) throw Exception('Le montant compté ne peut pas être négatif.');
    final db = await database;
    final expected = await cashBalance();
    await db.insert('cash_counts', {'expected_balance_mru':expected, 'counted_balance_mru':counted,
      'difference_mru':counted-expected, 'note':note.trim(), 'created_at':_now()});
  }

  Future<List<Map<String,Object?>>> cashCounts() async => (await database).query('cash_counts', orderBy:'id DESC', limit:10);

  Future<Map<String,Object?>> cashOverview() async => {'balance':await cashBalance(),'opening':await cashOpeningBalance(),
    'movements':await cashMovements(), 'counts':await cashCounts(), 'openingSet':await hasOpeningBalance()};

  Future<Map<String,Object?>> dashboard() async {
    final db = await database;
    final p = await db.rawQuery('SELECT COUNT(*) products, COALESCE(SUM(quantity),0) stock FROM products');
    final s = await db.rawQuery('SELECT COUNT(*) sales, COALESCE(SUM(balance_mru),0) debt FROM sales');
    return {'cash':await cashBalance(),'products':p.first['products'],'stock':p.first['stock'],
      'sales':s.first['sales'],'customerDebt':s.first['debt']};
  }
}
