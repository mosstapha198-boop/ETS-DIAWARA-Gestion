import 'package:flutter/material.dart';
import 'database.dart';
import 'format.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EtsDatabase.instance.database;
  runApp(const EtsDiawaraApp());
}

const navy = Color(0xFF142B4A);
const blue = Color(0xFF2F6FED);
const canvas = Color(0xFFF5F7FA);

class EtsDiawaraApp extends StatelessWidget {
  const EtsDiawaraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ETS DIAWARA Gestion',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: blue, primary: blue),
      scaffoldBackgroundColor: canvas,
      appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
        filled: true,
        fillColor: Colors.white,
      ),
      cardTheme: CardThemeData(
        color: Colors.white, elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFE3E8EF))),
      ),
    ),
    home: const HomeShell(),
  );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  int refreshKey = 0;
  final titles = const ['Vue d’ensemble', 'Produits & stock', 'Achats', 'Ventes', 'Caisse & trésorerie'];

  void refreshAll() => setState(() => refreshKey++);

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardScreen(key: ValueKey('d$refreshKey'), onNavigate: (i) => setState(() => tab = i)),
      ProductsScreen(key: ValueKey('p$refreshKey'), onChanged: refreshAll),
      PurchasesScreen(key: ValueKey('a$refreshKey'), onChanged: refreshAll),
      SalesScreen(key: ValueKey('v$refreshKey'), onChanged: refreshAll),
      CashScreen(key: ValueKey('c$refreshKey'), onChanged: refreshAll),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('ETS DIAWARA', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .5)),
          Text(titles[tab], style: const TextStyle(fontSize: 12, color: Colors.white70)),
        ]),
        actions: [IconButton(onPressed: refreshAll, icon: const Icon(Icons.refresh), tooltip: 'Actualiser')],
      ),
      body: SafeArea(child: screens[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Produits'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), selectedIcon: Icon(Icons.shopping_bag), label: 'Achats'),
          NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), selectedIcon: Icon(Icons.point_of_sale), label: 'Ventes'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Caisse'),
        ],
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const DashboardScreen({super.key, required this.onNavigate});
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, Object?>>(
    future: EtsDatabase.instance.dashboard(),
    builder: (context, snap) {
      final d = snap.data ?? {};
      return ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(18)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TABLEAU DE BORD', style: TextStyle(color: Colors.white70, letterSpacing: 1, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(formatMRU((d['cash'] as num?)?.toInt() ?? 0), style: const TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.bold)),
            const Text('Solde de caisse', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 14),
        Wrap(spacing: 10, runSpacing: 10, children: [
          _metric('Ventes enregistrées', '${d['sales'] ?? 0}', Icons.point_of_sale),
          _metric('Références produits', '${d['products'] ?? 0}', Icons.inventory_2),
          _metric('Unités en stock', '${d['stock'] ?? 0}', Icons.phone_android),
          _metric('Crédit clients', formatMRU((d['customerDebt'] as num?)?.toInt() ?? 0), Icons.receipt_long),
        ]),
        const SizedBox(height: 20),
        const Text('Accès rapide', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 8),
        _quick('Enregistrer un achat', 'Ajouter au stock et enregistrer le paiement fournisseur', Icons.add_shopping_cart, () => onNavigate(2)),
        _quick('Enregistrer une vente', 'Retirer du stock et enregistrer l’encaissement', Icons.point_of_sale, () => onNavigate(3)),
        _quick('Consulter la caisse', 'Voir les entrées et les sorties', Icons.account_balance_wallet, () => onNavigate(4)),
        const SizedBox(height: 16),
        const Text('Note : les chiffres sont calculés à partir de la base locale. Ajoute tes vrais produits avant utilisation.', style: TextStyle(color: Colors.black54, fontSize: 12)),
      ]);
    },
  );

  Widget _metric(String label, String value, IconData icon) => SizedBox(
    width: 160, child: Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: blue), const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy)),
        const SizedBox(height: 3), Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    ))),
  );

  Widget _quick(String title, String subtitle, IconData icon, VoidCallback action) => Card(
    child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFEAF0FF), child: Icon(icon, color: blue)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: action),
  );
}

class ProductsScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const ProductsScreen({super.key, required this.onChanged});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  Future<List<Map<String, Object?>>> _future = EtsDatabase.instance.products();
  void reload() => setState(() => _future = EtsDatabase.instance.products());

  Future<void> _addProduct() async {
    final brand = TextEditingController();
    final model = TextEditingController();
    final capacity = TextEditingController();
    final condition = ValueNotifier<String>('Neuf');
    final buy = TextEditingController(text: '0');
    final sell = TextEditingController(text: '0');
    final stock = TextEditingController(text: '0');
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Nouveau produit'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: brand, decoration: const InputDecoration(labelText: 'Marque')),
        const SizedBox(height: 8), TextField(controller: model, decoration: const InputDecoration(labelText: 'Modèle')),
        const SizedBox(height: 8), TextField(controller: capacity, decoration: const InputDecoration(labelText: 'Capacité / variante')),
        const SizedBox(height: 8), ValueListenableBuilder<String>(valueListenable: condition, builder: (_, v, __) =>
          DropdownButtonFormField<String>(value: v, decoration: const InputDecoration(labelText: 'État'), items: const [
            DropdownMenuItem(value: 'Neuf', child: Text('Neuf')),
            DropdownMenuItem(value: 'Reconditionné', child: Text('Reconditionné')),
          ], onChanged: (x) { if (x != null) condition.value = x; })),
        const SizedBox(height: 8), TextField(controller: buy, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix d’achat (MRU)')),
        const SizedBox(height: 8), TextField(controller: sell, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix de vente (MRU)')),
        const SizedBox(height: 8), TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stock initial')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
    ));
    if (ok == true) {
      try {
        await EtsDatabase.instance.addProduct(
          brand: brand.text, model: model.text, capacity: capacity.text, condition: condition.value,
          purchasePrice: int.tryParse(buy.text) ?? -1, salePrice: int.tryParse(sell.text) ?? -1,
          stock: int.tryParse(stock.text) ?? -1,
        );
        reload(); widget.onChanged();
        if (mounted) _toast('Produit enregistré.');
      } catch (e) { if (mounted) _toast(cleanError(e)); }
    }
    brand.dispose(); model.dispose(); capacity.dispose(); buy.dispose(); sell.dispose(); stock.dispose(); condition.dispose();
  }

  void _toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(14), children: [
    Row(children: [const Expanded(child: Text('Catalogue produits', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy))),
      FilledButton.icon(onPressed: _addProduct, icon: const Icon(Icons.add), label: const Text('Ajouter'))]),
    const SizedBox(height: 10),
    FutureBuilder<List<Map<String, Object?>>>(future: _future, builder: (_, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      final rows = snap.data ?? [];
      if (rows.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Aucun produit. Appuie sur Ajouter pour créer ton catalogue.')));
      return Column(children: rows.map<Widget>((p) => Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFEAF0FF), child: Icon(Icons.phone_android, color: blue)),
        title: Text('${p['brand']} ${p['model']}', style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${p['capacity']} • ${p['condition']}\nAchat ${formatMRU(p['purchase_price_mru'] as int)} • Vente ${formatMRU(p['sale_price_mru'] as int)}'),
        isThreeLine: true, trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('STOCK', style: TextStyle(fontSize: 10, color: Colors.black54)),
          Text('${p['quantity']}', style: TextStyle(fontWeight: FontWeight.bold, color: (p['quantity'] as int) <= (p['alert_threshold'] as int) ? Colors.red : navy)),
        ]),
      )).toList());
    }),
  ]);
}

class PurchasesScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const PurchasesScreen({super.key, required this.onChanged});
  @override
  State<PurchasesScreen> createState() => _PurchasesScreenState();
}

class _PurchasesScreenState extends State<PurchasesScreen> {
  Future<List<Map<String, Object?>>> _future = EtsDatabase.instance.purchaseHistory();

  Future<void> _newPurchase() async {
    final products = await EtsDatabase.instance.products();
    if (!mounted) return;
    if (products.isEmpty) { _toast('Ajoute d’abord un produit dans Produits & stock.'); return; }
    int productId = products.first['id'] as int;
    final supplier = TextEditingController();
    final reference = TextEditingController(text: 'ACH-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}');
    final qty = TextEditingController(text: '1');
    final unitCost = TextEditingController(text: '${products.first['purchase_price_mru']}');
    final transport = TextEditingController(text: '0');
    final other = TextEditingController(text: '0');
    final paid = TextEditingController(text: '0');
    final chosen = ValueNotifier<int>(productId);
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: const Text('Enregistrer un achat'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: supplier, decoration: const InputDecoration(labelText: 'Fournisseur')),
        const SizedBox(height: 8), TextField(controller: reference, decoration: const InputDecoration(labelText: 'Référence / facture fournisseur')),
        const SizedBox(height: 8), DropdownButtonFormField<int>(value: chosen.value, isExpanded: true, decoration: const InputDecoration(labelText: 'Produit reçu'),
          items: products.map((p) => DropdownMenuItem(value: p['id'] as int, child: Text('${p['brand']} ${p['model']} (${p['quantity']} en stock)'))).toList(),
          onChanged: (v) { if (v != null) { chosen.value = v; final p = products.firstWhere((x) => x['id'] == v); unitCost.text = '${p['purchase_price_mru']}'; setD(() {}); } }),
        const SizedBox(height: 8), TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité achetée')),
        const SizedBox(height: 8), TextField(controller: unitCost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix d’achat unitaire (MRU)')),
        const SizedBox(height: 8), TextField(controller: transport, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Transport (MRU)')),
        const SizedBox(height: 8), TextField(controller: other, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Autres frais (MRU)')),
        const SizedBox(height: 8), TextField(controller: paid, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Montant payé au fournisseur (MRU)')),
        const SizedBox(height: 8), const Text('Le stock augmentera automatiquement après validation.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Valider l’achat'))],
    )));
    if (ok == true) {
      try {
        await EtsDatabase.instance.createPurchase(
          productId: chosen.value, supplier: supplier.text, reference: reference.text,
          quantity: int.tryParse(qty.text) ?? 0, unitCost: int.tryParse(unitCost.text) ?? -1,
          transport: int.tryParse(transport.text) ?? -1, other: int.tryParse(other.text) ?? -1,
          paid: int.tryParse(paid.text) ?? -1,
        );
        setState(() => _future = EtsDatabase.instance.purchaseHistory());
        widget.onChanged();
        if (mounted) _toast('Achat enregistré : le stock a été augmenté.');
      } catch (e) { if (mounted) _toast(cleanError(e)); }
    }
    supplier.dispose(); reference.dispose(); qty.dispose(); unitCost.dispose(); transport.dispose(); other.dispose(); paid.dispose(); chosen.dispose();
  }

  void _toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(14), children: [
    Row(children: [const Expanded(child: Text('Historique des achats', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy))),
      FilledButton.icon(onPressed: _newPurchase, icon: const Icon(Icons.add), label: const Text('Nouvel achat'))]),
    const SizedBox(height: 10),
    FutureBuilder<List<Map<String, Object?>>>(future: _future, builder: (_, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      final rows = snap.data ?? [];
      if (rows.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Aucun achat. Crée un achat pour enregistrer les entrées de stock.')));
      return Column(children: rows.map((r) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.local_shipping_outlined)),
        title: Text('${r['purchase_number']} • ${r['product_label']}'),
        subtitle: Text('${r['supplier']} • ${r['quantity']} unité(s)\nTotal ${formatMRU(r['total_mru'] as int)} • payé ${formatMRU(r['paid_mru'] as int)} • reste ${formatMRU(r['balance_mru'] as int)}'),
        isThreeLine: true,
      ))).toList());
    }),
  ]);
}

class SalesScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const SalesScreen({super.key, required this.onChanged});
  @override
  State<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  Future<List<Map<String, Object?>>> _future = EtsDatabase.instance.salesHistory();

  Future<void> _newSale() async {
    final products = await EtsDatabase.instance.products();
    if (!mounted) return;
    if (products.isEmpty) { _toast('Ajoute d’abord un produit.'); return; }
    int id = products.first['id'] as int;
    final qty = TextEditingController(text: '1');
    final paid = TextEditingController();
    final chosen = ValueNotifier<int>(id);
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: const Text('Enregistrer une vente'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<int>(value: chosen.value, isExpanded: true, decoration: const InputDecoration(labelText: 'Produit'),
          items: products.map((p) => DropdownMenuItem(value: p['id'] as int, child: Text('${p['brand']} ${p['model']} • stock ${p['quantity']}'))).toList(),
          onChanged: (v) { if (v != null) { chosen.value = v; setD(() {}); } }),
        const SizedBox(height: 8), TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité vendue')),
        const SizedBox(height: 8), TextField(controller: paid, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Montant encaissé (vide = total)')),
        const SizedBox(height: 8), const Text('La vente diminue le stock. Seul le montant encaissé entre dans la caisse.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Valider la vente'))],
    )));
    if (ok == true) {
      final product = products.firstWhere((p) => p['id'] == chosen.value);
      final q = int.tryParse(qty.text) ?? 0;
      final total = (product['sale_price_mru'] as int) * q;
      try {
        await EtsDatabase.instance.createSale(productId: chosen.value, quantity: q,
          paid: paid.text.trim().isEmpty ? total : (int.tryParse(paid.text) ?? -1));
        setState(() => _future = EtsDatabase.instance.salesHistory());
        widget.onChanged();
        if (mounted) _toast('Vente enregistrée : stock et caisse mis à jour.');
      } catch (e) { if (mounted) _toast(cleanError(e)); }
    }
    qty.dispose(); paid.dispose(); chosen.dispose();
  }

  void _toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(14), children: [
    Row(children: [const Expanded(child: Text('Historique des ventes', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy))),
      FilledButton.icon(onPressed: _newSale, icon: const Icon(Icons.add), label: const Text('Nouvelle vente'))]),
    const SizedBox(height: 10),
    FutureBuilder<List<Map<String, Object?>>>(future: _future, builder: (_, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      final rows = snap.data ?? [];
      if (rows.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Aucune vente.')));
      return Column(children: rows.map((r) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
        title: Text('${r['sale_number']} • ${r['product_label']}'),
        subtitle: Text('${r['quantity']} unité(s) • total ${formatMRU(r['total_mru'] as int)}\nPayé ${formatMRU(r['paid_mru'] as int)} • reste ${formatMRU(r['balance_mru'] as int)}'),
        isThreeLine: true,
      ))).toList());
    }),
  ]);
}

class CashScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const CashScreen({super.key, required this.onChanged});
  @override
  State<CashScreen> createState() => _CashScreenState();
}

class _CashScreenState extends State<CashScreen> {
  Future<Map<String, Object?>> _future = EtsDatabase.instance.cashOverview();
  void _reload() => setState(() => _future = EtsDatabase.instance.cashOverview());

  Future<void> _setOpening() async {
    final amount = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Définir le solde initial'),
      content: TextField(controller: amount, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Argent présent au départ (MRU)', hintText: 'Ex. 50000')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
    ));
    if (ok == true) {
      try { await EtsDatabase.instance.setOpeningBalance(int.tryParse(amount.text) ?? -1); _reload(); widget.onChanged();
        if (mounted) _toast('Solde initial enregistré.');
      } catch (e) { if (mounted) _toast(cleanError(e)); }
    }
    amount.dispose();
  }

  Future<void> _addMovement(String kind) async {
    final label = TextEditingController();
    final category = TextEditingController(text: kind == 'IN' ? 'ENTRÉE DIVERSE' : 'DÉPENSE');
    final amount = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text(kind == 'IN' ? 'Enregistrer une entrée réelle' : 'Enregistrer une sortie réelle'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: category, decoration: const InputDecoration(labelText: 'Catégorie')),
        const SizedBox(height: 8), TextField(controller: label, decoration: const InputDecoration(labelText: 'Motif / description')),
        const SizedBox(height: 8), TextField(controller: amount, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Montant réellement reçu/payé (MRU)')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
    ));
    if (ok == true) {
      try { await EtsDatabase.instance.addCashMovement(kind:kind, category:category.text, label:label.text,
          amount:int.tryParse(amount.text) ?? 0); _reload(); widget.onChanged();
        if (mounted) _toast(kind == 'IN' ? 'Entrée de caisse enregistrée.' : 'Sortie de caisse enregistrée.');
      } catch (e) { if (mounted) _toast(cleanError(e)); }
    }
    label.dispose(); category.dispose(); amount.dispose();
  }

  Future<void> _countCash() async {
    final counted = TextEditingController();
    final note = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Comptage physique de la caisse'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: counted, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Argent réellement compté (MRU)')),
        const SizedBox(height: 8), TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (facultatif)')),
        const SizedBox(height: 8), const Text('Le comptage compare l’argent compté au solde théorique. Il ne modifie pas les mouvements.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Comparer'))],
    ));
    if (ok == true) {
      try { await EtsDatabase.instance.recordCashCount(counted:int.tryParse(counted.text) ?? -1, note:note.text); _reload(); widget.onChanged();
        if (mounted) _toast('Comptage enregistré. Consulte l’écart dans le dernier comptage.');
      } catch (e) { if (mounted) _toast(cleanError(e)); }
    }
    counted.dispose(); note.dispose();
  }

  void _toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, Object?>>(
    future: _future,
    builder: (_, snap) {
      final data = snap.data ?? {};
      final rows = (data['movements'] as List<Map<String, Object?>>?) ?? [];
      final counts = (data['counts'] as List<Map<String, Object?>>?) ?? [];
      final openingSet = data['openingSet'] == true;
      final opening = (data['opening'] as num?)?.toInt() ?? 0;
      final balance = (data['balance'] as num?)?.toInt() ?? 0;
      final latestCount = counts.isNotEmpty ? counts.first : null;
      return ListView(padding: const EdgeInsets.all(14), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('SOLDE THÉORIQUE DE CAISSE', style: TextStyle(color: Colors.black54, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8), Text(formatMRU(balance), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: navy)),
          const Text('Solde initial + entrées réelles − sorties réelles', style: TextStyle(color: Colors.black54, fontSize: 12)),
          const SizedBox(height: 8), Text('Solde initial : ${formatMRU(opening)}', style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 12), Wrap(spacing: 8, runSpacing: 8, children: [
            OutlinedButton.icon(onPressed: openingSet ? null : _setOpening, icon: const Icon(Icons.flag_outlined), label: const Text('Solde initial')),
            FilledButton.icon(onPressed: () => _addMovement('IN'), icon: const Icon(Icons.add), label: const Text('Entrée')),
            FilledButton.tonalIcon(onPressed: () => _addMovement('OUT'), icon: const Icon(Icons.remove), label: const Text('Sortie')),
            OutlinedButton.icon(onPressed: _countCash, icon: const Icon(Icons.fact_check_outlined), label: const Text('Compter la caisse')),
          ]),
        ]))),
        if (latestCount != null) Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('DERNIER COMPTAGE PHYSIQUE', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 8), Text('Solde théorique : ${formatMRU(latestCount['expected_balance_mru'] as int)}'),
          Text('Argent compté : ${formatMRU(latestCount['counted_balance_mru'] as int)}'),
          const SizedBox(height: 6),
          Text('Écart : ${formatMRU(latestCount['difference_mru'] as int)}', style: TextStyle(fontWeight: FontWeight.bold,
            color: (latestCount['difference_mru'] as int) == 0 ? Colors.green : Colors.red)),
          if ((latestCount['note'] as String).isNotEmpty) Text('Note : ${latestCount['note']}'),
          Text('${latestCount['created_at']}', style: const TextStyle(fontSize: 11, color: Colors.black54)),
        ]))),
        const SizedBox(height: 10), const Text('Derniers mouvements', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: navy)),
        if (rows.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Aucun mouvement de caisse.')))
        else ...rows.map((m) {
          final isIn = m['kind'] == 'IN';
          return Card(child: ListTile(
            leading: Icon(isIn ? Icons.south_west : Icons.north_east, color: isIn ? Colors.green : Colors.red),
            title: Text(m['label'] as String),
            subtitle: Text('${m['category']} • ${m['created_at']}'),
            trailing: Text('${isIn ? '+' : '-'}${formatMRU(m['amount_mru'] as int)}', style: TextStyle(color: isIn ? Colors.green : Colors.red, fontWeight: FontWeight.bold)),
          ));
        }),
      ]);
    },
  );
}

String cleanError(Object e) => e.toString().replaceFirst('Exception: ', '').replaceFirst('StateError: ', '');
